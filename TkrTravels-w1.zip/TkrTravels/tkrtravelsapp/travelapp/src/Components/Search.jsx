import React from 'react'
import '../styles/Search.css'

function Search() {
  return (
    <div className="search">
        <div className="search-in">
        <input className='search-b' type="text" placeholder='search for your destination' />
        </div>   
             
    </div>
             
            
  )
}

export default Search